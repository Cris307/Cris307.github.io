package com.example.weighttrackingapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.weighttrackingapplication.databinding.ActivityLoginBinding

// LoginActivity manages user authentication for the app.
// It allows users to log in to an existing account or register a new one.
class LoginActivity : AppCompatActivity() {

    // ViewBinding provides access to the layout elements in activity_login.xml
    private lateinit var binding: ActivityLoginBinding
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize database helper to manage user login and registration
        dbHelper = DatabaseHelper(this)

        // ---------------- LOGIN BUTTON ----------------
        // Handles login attempts: verifies credentials and navigates to HomeActivity if valid.
        binding.buttonLogin.setOnClickListener {
            val username = binding.editUsername.text.toString().trim()
            val password = binding.editPassword.text.toString().trim()

            // Basic input validation
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show()
            }
            // Check if username and password match an existing account
            else if (dbHelper.checkUser(username, password)) {
                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, HomeActivity::class.java)
                intent.putExtra("username", username)
                startActivity(intent)
                finish()
            }
            // If username exists but password is wrong
            else if (dbHelper.userExists(username)) {
                Toast.makeText(this, "Incorrect password. Please try again.", Toast.LENGTH_SHORT).show()
            }
            // If no account exists for entered username
            else {
                Toast.makeText(this, "Account not found. Please create one first.", Toast.LENGTH_SHORT).show()
            }
        }

        // ---------------- REGISTER BUTTON ----------------
        // Handles new user registration: creates account and navigates to HomeActivity.
        binding.buttonRegister.setOnClickListener {
            val username = binding.editUsername.text.toString().trim()
            val password = binding.editPassword.text.toString().trim()

            // Validate input before registration
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show()
            }
            // Prevent duplicate usernames
            else if (dbHelper.userExists(username)) {
                Toast.makeText(this, "Username already exists. Please log in.", Toast.LENGTH_SHORT).show()
            }
            // Create a new account and open the HomeActivity
            else {
                val created = dbHelper.insertUser(username, password)
                if (created) {
                    Toast.makeText(this, "New account created successfully!", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, HomeActivity::class.java)
                    intent.putExtra("username", username)
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this, "Error creating account. Try again.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
