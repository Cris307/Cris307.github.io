package com.example.weighttrackingapplication

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.weighttrackingapplication.databinding.ActivityGoalSettingBinding

// GoalSettingActivity handles the screen where the user can set a goal weight manually.
// This activity updates the button text to confirm when a goal is saved.
class GoalSettingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGoalSettingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityGoalSettingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // When user taps the Save button, retrieve input goal and update the button text
        binding.buttonSaveGoal.setOnClickListener {
            val goal = binding.editGoalWeight.text.toString()
            binding.editGoalWeight.setText("")
            binding.buttonSaveGoal.text = "Saved: $goal lbs"
        }
    }
}
