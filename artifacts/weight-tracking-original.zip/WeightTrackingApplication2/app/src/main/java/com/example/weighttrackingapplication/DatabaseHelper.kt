package com.example.weighttrackingapplication

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// DatabaseHelper manages all SQLite database operations for the app.
// It handles user accounts, target weights, and weight record storage.
class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "WeightTrackingApp.db"
        private const val DATABASE_VERSION = 3   // database version with target weight support

        // ---------- USER TABLE ----------
        const val TABLE_USERS = "users"
        const val COLUMN_ID = "id"
        const val COLUMN_USERNAME = "username"
        const val COLUMN_PASSWORD = "password"
        const val COLUMN_TARGET = "target_weight"

        // ---------- WEIGHT TABLE ----------
        const val TABLE_WEIGHT = "weight_records"
        const val COLUMN_RECORD_ID = "record_id"
        const val COLUMN_DATE = "date"
        const val COLUMN_WEIGHT = "weight"
        const val COLUMN_USER = "user"
    }

    // Called when the database is first created.
    // Defines tables for users and weight records.
    override fun onCreate(db: SQLiteDatabase) {
        val createUsersTable = """
            CREATE TABLE $TABLE_USERS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_USERNAME TEXT UNIQUE,
                $COLUMN_PASSWORD TEXT,
                $COLUMN_TARGET REAL
            )
        """.trimIndent()

        val createWeightTable = """
            CREATE TABLE $TABLE_WEIGHT (
                $COLUMN_RECORD_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_DATE TEXT,
                $COLUMN_WEIGHT REAL,
                $COLUMN_USER TEXT,
                FOREIGN KEY($COLUMN_USER) REFERENCES $TABLE_USERS($COLUMN_USERNAME)
            )
        """.trimIndent()

        db.execSQL(createUsersTable)
        db.execSQL(createWeightTable)
    }

    // Called when the database version is updated.
    // Adds the target_weight column if needed and ensures tables exist.
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 3) {
            try {
                db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_TARGET REAL")
            } catch (e: Exception) {
                // Ignore if the column already exists
            }
        }

        db.execSQL("CREATE TABLE IF NOT EXISTS $TABLE_WEIGHT (" +
                "$COLUMN_RECORD_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_DATE TEXT, " +
                "$COLUMN_WEIGHT REAL, " +
                "$COLUMN_USER TEXT, " +
                "FOREIGN KEY($COLUMN_USER) REFERENCES $TABLE_USERS($COLUMN_USERNAME))")
    }

    // ---------- USER ACCOUNT METHODS ----------
    // Handles user registration, login, and existence checks.

    fun insertUser(username: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_USERNAME, username)
            put(COLUMN_PASSWORD, password)
            put(COLUMN_TARGET, 0.0)
        }
        val result = db.insert(TABLE_USERS, null, values)
        db.close()
        return result != -1L
    }

    fun checkUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM $TABLE_USERS WHERE $COLUMN_USERNAME=? AND $COLUMN_PASSWORD=?",
            arrayOf(username, password)
        )
        val exists = cursor.count > 0
        cursor.close()
        db.close()
        return exists
    }

    fun userExists(username: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM $TABLE_USERS WHERE $COLUMN_USERNAME=?",
            arrayOf(username)
        )
        val exists = cursor.count > 0
        cursor.close()
        db.close()
        return exists
    }

    // ---------- TARGET WEIGHT METHODS ----------
    // Retrieves and updates the user's target weight.

    fun getTargetWeight(username: String): Double? {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT $COLUMN_TARGET FROM $TABLE_USERS WHERE $COLUMN_USERNAME=?",
            arrayOf(username)
        )
        val target = if (cursor.moveToFirst()) cursor.getDouble(0) else null
        cursor.close()
        db.close()
        return target
    }

    fun updateTargetWeight(username: String, target: Double): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_TARGET, target)
        }
        val result = db.update(TABLE_USERS, values, "$COLUMN_USERNAME=?", arrayOf(username))
        db.close()
        return result > 0
    }

    // ---------- WEIGHT RECORD METHODS ----------
    // Handles CRUD operations for daily weight entries.

    fun insertWeight(username: String, date: String, weight: Double): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_USER, username)
            put(COLUMN_DATE, date)
            put(COLUMN_WEIGHT, weight)
        }
        val result = db.insert(TABLE_WEIGHT, null, values)
        db.close()
        return result != -1L
    }

    fun getAllWeights(username: String): Cursor {
        val db = readableDatabase
        return db.rawQuery(
            "SELECT $COLUMN_RECORD_ID AS _id, $COLUMN_DATE, $COLUMN_WEIGHT, $COLUMN_USER " +
                    "FROM $TABLE_WEIGHT WHERE $COLUMN_USER = ? ORDER BY $COLUMN_DATE DESC",
            arrayOf(username)
        )
    }

    fun updateWeight(recordId: Int, newWeight: Double): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_WEIGHT, newWeight)
        }
        val result = db.update(TABLE_WEIGHT, values, "$COLUMN_RECORD_ID=?", arrayOf(recordId.toString()))
        db.close()
        return result > 0
    }

    fun deleteWeight(recordId: Int): Boolean {
        val db = writableDatabase
        val result = db.delete(TABLE_WEIGHT, "$COLUMN_RECORD_ID=?", arrayOf(recordId.toString()))
        db.close()
        return result > 0
    }
}
