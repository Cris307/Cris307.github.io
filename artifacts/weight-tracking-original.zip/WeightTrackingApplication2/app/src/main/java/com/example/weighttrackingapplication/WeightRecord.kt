package com.example.weighttrackingapplication

data class WeightRecord(
    val id: Int,
    val date: String,
    val weight: Double
)
