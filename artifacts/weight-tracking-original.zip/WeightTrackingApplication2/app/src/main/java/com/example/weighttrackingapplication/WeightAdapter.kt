package com.example.weighttrackingapplication

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

// WeightAdapter handles the display and interaction of each weight record item
// inside the list view in HomeActivity. It allows users to edit or delete entries.
class WeightAdapter(
    private val context: Context,
    private val data: MutableList<WeightRecord>,
    private val dbHelper: DatabaseHelper,
    private val username: String,
    private val onRefresh: () -> Unit
) : ArrayAdapter<WeightRecord>(context, 0, data) {

    // getView inflates each list item and defines behavior for edit and delete buttons
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.weight_item, parent, false)

        // Retrieve the current record and UI components for this list item
        val record = data[position]
        val textDate = view.findViewById<TextView>(R.id.textDate)
        val textWeight = view.findViewById<TextView>(R.id.textWeight)
        val buttonEdit = view.findViewById<Button>(R.id.buttonEdit)
        val buttonDelete = view.findViewById<Button>(R.id.buttonDelete)

        // Display record information
        textDate.text = "Date: ${record.date}"
        textWeight.text = "Weight: ${record.weight} lbs"

        // ---------------- DELETE FUNCTIONALITY ----------------
        // When delete button is clicked, show confirmation dialog and remove record
        buttonDelete.setOnClickListener {
            AlertDialog.Builder(context)
                .setTitle("Delete Entry")
                .setMessage("Delete this record?")
                .setPositiveButton("Yes") { _, _ ->
                    dbHelper.deleteWeight(record.id)
                    Toast.makeText(context, "Record deleted", Toast.LENGTH_SHORT).show()
                    onRefresh() // refresh the list view after deletion
                }
                .setNegativeButton("No", null)
                .show()
        }

        // ---------------- EDIT FUNCTIONALITY ----------------
        // When edit button is clicked, show dialog to change date or weight
        buttonEdit.setOnClickListener {
            val inputView = LayoutInflater.from(context)
                .inflate(R.layout.dialog_edit_weight, null)

            val editDate = inputView.findViewById<EditText>(R.id.editDate)
            val editWeight = inputView.findViewById<EditText>(R.id.editWeight)
            editDate.setText(record.date)
            editWeight.setText(record.weight.toString())

            AlertDialog.Builder(context)
                .setTitle("Edit Weight Record")
                .setView(inputView)
                .setPositiveButton("Save") { _, _ ->
                    val newDate = editDate.text.toString()
                    val newWeight = editWeight.text.toString().toDoubleOrNull()

                    // Validate input before updating
                    if (!newDate.isNullOrBlank() && newWeight != null) {
                        dbHelper.updateWeight(record.id, newWeight)
                        dbHelper.insertWeight(username, newDate, newWeight) // optional: saves with new date
                        Toast.makeText(context, "Record updated", Toast.LENGTH_SHORT).show()
                        onRefresh() // refresh list to show updates
                    } else {
                        Toast.makeText(context, "Invalid input", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        return view
    }
}
