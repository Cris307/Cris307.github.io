package com.example.weighttrackingapplication

import android.Manifest
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.weighttrackingapplication.databinding.ActivityHomeBinding
import java.text.SimpleDateFormat
import java.util.*

// HomeActivity manages the main screen where users can log daily weights,
// set target goals, and receive notifications when their goal is achieved.
class HomeActivity : AppCompatActivity() {

    // UI binding and database setup
    private lateinit var binding: ActivityHomeBinding
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var username: String
    private lateinit var weightList: MutableList<WeightRecord>
    private lateinit var adapter: WeightAdapter

    companion object {
        // Notification configuration constants
        private const val CHANNEL_ID = "goal_channel"
        private const val NOTIFICATION_ID = 1001
        private const val REQUEST_NOTIFICATION_PERMISSION = 10
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize database and get logged-in username
        dbHelper = DatabaseHelper(this)
        username = intent.getStringExtra("username") ?: "Guest"
        binding.textWelcome.text = "Welcome, $username"

        // Set up notifications and permission prompts
        createNotificationChannel()
        askNotificationPermission()

        // Load and display user's target weight
        loadTargetWeight()
        binding.buttonSetTarget.setOnClickListener { showSetTargetDialog() }

        // Display existing weight records in the list
        loadWeights()

        // Add a new weight entry and check for goal completion
        binding.buttonAddWeight.setOnClickListener {
            val weightInput = binding.editWeight.text.toString()
            if (weightInput.isNotEmpty()) {
                val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                val currentWeight = weightInput.toDouble()
                if (dbHelper.insertWeight(username, date, currentWeight)) {
                    Toast.makeText(this, "Weight added!", Toast.LENGTH_SHORT).show()
                    binding.editWeight.text.clear()
                    loadWeights()

                    // If the new weight equals the user's target, send a notification
                    val target = dbHelper.getTargetWeight(username)
                    if (target != null && currentWeight == target) {
                        sendGoalAchievedNotification()
                    }
                }
            } else {
                Toast.makeText(this, "Enter a weight", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------------- Target Weight Logic ----------------
    // Loads and displays the current target weight from the database.
    private fun loadTargetWeight() {
        val target = dbHelper.getTargetWeight(username)
        if (target != null && target > 0.0) {
            binding.textTargetWeight.text = "$target lbs"
        } else {
            binding.textTargetWeight.text = "Not set"
        }
    }

    // Displays a dialog allowing the user to enter or update their target weight.
    private fun showSetTargetDialog() {
        val input = EditText(this)
        input.hint = "Enter target weight (lbs)"
        AlertDialog.Builder(this)
            .setTitle("Set Target Weight")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().toDoubleOrNull()
                if (value != null) {
                    dbHelper.updateTargetWeight(username, value)
                    binding.textTargetWeight.text = "$value lbs"
                    Toast.makeText(this, "Target weight saved!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------- Weight Records Logic ----------------
    // Loads all weight entries for the current user and displays them in a list.
    private fun loadWeights() {
        val cursor = dbHelper.getAllWeights(username)
        weightList = mutableListOf()
        if (cursor.moveToFirst()) {
            val idIndex = cursor.getColumnIndex("_id")
            val dateIndex = cursor.getColumnIndex("date")
            val weightIndex = cursor.getColumnIndex("weight")
            do {
                val id = cursor.getInt(idIndex)
                val date = cursor.getString(dateIndex)
                val weight = cursor.getDouble(weightIndex)
                weightList.add(WeightRecord(id, date, weight))
            } while (cursor.moveToNext())
        }
        cursor.close()

        adapter = WeightAdapter(this, weightList, dbHelper, username) {
            loadWeights()
        }
        binding.listViewWeights.adapter = adapter
    }

    // ---------------- Notification Logic ----------------
    // Creates a notification channel for goal alerts (required for Android 8.0+).
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Goal Notifications"
            val descriptionText = "Notifications when weight goal is achieved"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    // Requests permission to send notifications (Android 13+ only).
    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    REQUEST_NOTIFICATION_PERMISSION
                )
            }
        }
    }

    // Sends a notification to congratulate the user when their goal is achieved.
    private fun sendGoalAchievedNotification() {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.star_on)
            .setContentTitle("Goal Achieved!")
            .setContentText("🎉 Congratulations! You've reached your target weight.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        with(NotificationManagerCompat.from(this)) {
            if (ActivityCompat.checkSelfPermission(
                    this@HomeActivity,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                notify(NOTIFICATION_ID, builder.build())
            }
        }
    }
}
